
/*
 * CS252: Shell project
 *
 * Template file.
 * You will need to add more code here to execute the command table.
 *
 * NOTE: You are responsible for fixing any bugs this code may have!
 *
 */
//export LC_ALL=C
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <dirent.h>
#include "command.h"
#include <errno.h>
int pid = 0;
char * last;

SimpleCommand::SimpleCommand()
{
	// Create available space for 5 arguments
	_numOfAvailableArguments = 5;
	_numOfArguments = 0;
	_arguments = (char **) malloc( _numOfAvailableArguments * sizeof( char * ) );
}

void//int process = getpid()
SimpleCommand::insertArgument( char * argument )
{
	if ( _numOfAvailableArguments == _numOfArguments  + 1 ) {
		// Double the available space
		_numOfAvailableArguments *= 2;
		_arguments = (char **) realloc( _arguments,
				  _numOfAvailableArguments * sizeof( char * ) );
	}

	char * expand = (char *)malloc(1000);
	char * envname = (char *)malloc(1000);
	int n = 0;
	char * newarg = (char *)malloc(1000);
	int argindex = 0;
	int flag = 0;
	int flag2 = 0;
	//int len = sizeof(argument);
			if (!strcmp(argument,"${$}")) {
			int process = getpid();
			const char* set = "$";
			char buff[50];
			sprintf(buff,"%s=%d",set,process);
			putenv(buff);
			printf("%d\n",process);
			return;
			}
			if (!strcmp(argument,"${SHELL}")) {
			const char * current = "./shell";
			printf("%s\n",current);
			return;
			}

	for (int i = 0; i < argument[i] != '\0'; i++) {
		if(argument[i+2] == '!') {
			flag2 = 1;
		}
		if (!strcmp(argument,"${!}")) {
			printf("%d\n",pid);
			break;
		}
		if (!strcmp(argument,"${_}")) {
			printf("%s\n",last);
			break;
		} 

		if (argument[i] == '$' && flag2 == 0) {
			i = i + 2;
			while (argument[i] != '}') {
				envname[n] = argument[i];
				n = n + 1;
				i = i + 1;
			}
			envname[n] = '\0';
			expand = getenv(envname);
			strcat(newarg,expand);
			argindex = argindex + strlen(expand);
			n = 0;
		} else {
			newarg[argindex] = argument[i];
			argindex = argindex + 1;
		}
	}
	if (newarg[0] == '~') {
		flag = 1;
		if (newarg[1] == '\0') {
			//char * tilde = (char *)malloc(1000);
			char * value = getenv("HOME");
			//const char * temp = "/homes/";
			//int tmplen = strlen(temp);
			//memcpy(tilde,&temp[0],tmplen);
			//strcat(tilde,value);
			newarg = strdup(value);
		//printf("%c\n",newarg[1]);
		//printf("hello\n");
		} else {
			char * tilde = (char *)malloc(1000);
			char * newnewarg = (char *)malloc(1000);
			const char * temp = "/homes/";
			int tmplen = strlen(temp);
			memcpy(tilde,&temp[0],tmplen);
			int length = strlen(newarg);
			memcpy(newnewarg,&newarg[1],length-1);
			strcat(tilde,newnewarg);
			newarg = strdup(tilde);
		}
	}
	if (flag == 0) {
	newarg[argindex] = '\0';
	}
	_arguments[ _numOfArguments ] = strdup(newarg);

	// Add NULL argument at the end
	_arguments[ _numOfArguments + 1] = NULL;

	_numOfArguments++;
	//}
}

Command::Command()
{
	// Create available space for one simple command
	_numOfAvailableSimpleCommands = 1;
	_simpleCommands = (SimpleCommand **)
		malloc( _numOfSimpleCommands * sizeof( SimpleCommand * ) );

	_numOfSimpleCommands = 0;
	_outFile = 0;
	_inFile = 0;
	_errFile = 0;
	_append = 0;
	_background = 0;
	_ambi = 0;
}

void
Command::insertSimpleCommand( SimpleCommand * simpleCommand )
{
	if ( _numOfAvailableSimpleCommands == _numOfSimpleCommands ) {
		_numOfAvailableSimpleCommands *= 2;
		_simpleCommands = (SimpleCommand **) realloc( _simpleCommands,
			 _numOfAvailableSimpleCommands * sizeof( SimpleCommand * ) );
	}

	_simpleCommands[ _numOfSimpleCommands ] = simpleCommand;
	_numOfSimpleCommands++;
}

void
Command:: clear()
{
	for ( int i = 0; i < _numOfSimpleCommands; i++ ) {
		for ( int j = 0; j < _simpleCommands[ i ]->_numOfArguments; j ++ ) {
			free ( _simpleCommands[ i ]->_arguments[ j ] );
		}

		free ( _simpleCommands[ i ]->_arguments );
		free ( _simpleCommands[ i ] );
	}

	if ( _outFile ) {
		free( _outFile );
	}

	if ( _inFile ) {
		free( _inFile );
	}

	if ( _errFile ) {
		free( _errFile );
	}

	_numOfSimpleCommands = 0;
	_outFile = 0;
	_inFile = 0;
	_errFile = 0;
	_append = 0;
	_background = 0;
	_ambi = 0;
}

void
Command::print()
{
	printf("\n\n");
	printf("              COMMAND TABLE                \n");
	printf("\n");
	printf("  #   Simple Commands\n");
	printf("  --- ----------------------------------------------------------\n");

	for ( int i = 0; i < _numOfSimpleCommands; i++ ) {
		printf("  %-3d ", i );
		for ( int j = 0; j < _simpleCommands[i]->_numOfArguments; j++ ) {
			printf("\"%s\" \t", _simpleCommands[i]->_arguments[ j ] );
		}
		printf("\n");
	}

	printf( "\n\n" );
	printf( "  Output       Input        Error        Background\n" );
	printf( "  ------------ ------------ ------------ ------------\n" );
	printf( "  %-12s %-12s %-12s %-12s\n", _outFile?_outFile:"default",
		_inFile?_inFile:"default", _errFile?_errFile:"default",
		_background?"YES":"NO");
	printf( "\n\n" );

}

void disp( int sig )
{
	printf("\n");
	Command::_currentCommand.clear();
	Command::_currentCommand.prompt();
}

void disp2( int sig )
{
	//printf("\n");
	//Command::_currentCommand.clear();
	//Command::_currentCommand.prompt();
}

void killzombie(int sig) {
	//wait3(0,0,NULL);
	while(waitpid(-1, NULL, WNOHANG) > 0);
}

void
Command::execute()
{
	// Don't do anything if there are no simple commandss
	if ( _numOfSimpleCommands == 0 ) {
		prompt();
		return;
	}

	if (_ambi == 1) {
		printf("Ambiguous output redirect\n");
		clear();
		prompt();
		return;
	}
	// Print contents of Command data structure
	//print();

	// Add execution here
	// For every simple command fork a new process
	// Setup i/o redirection
	// and call exec
	int tmpin = dup( 0 );
	int tmpout = dup( 1 );
	int tmperr = dup( 2 );
	int fdin;
	//struct stat st;
    //int result = stat(_inFile, &st);
	if (_inFile) {
		fdin = open(_inFile,O_RDONLY);
		if (fdin == -1) {
			//printf("-bash: files/aaa: No such file or directory\n");
			perror("open");
			clear();
			prompt();
			//printf("hello\n");
			//isatty(fdin);
			return;
		}
	} else {
		fdin = dup(tmpin);
	}

	int ret;
	int fdout;
	//int fdpipe[2];
	//_arguments[_simpleCommands[0]->_numOfArguments-1] != NULL
	//last = (char *)malloc(sizeof(char)*100);
	//last = strdup(_simpleCommands[_numOfSimpleCommands-1]->_arguments[_simpleCommands[_numOfSimpleCommands-1]->_numOfArguments-1]);
	for (int i = 0; i < _numOfSimpleCommands; i++) {
		dup2(fdin,0);
		close(fdin);
		if (i == _numOfSimpleCommands - 1) {
			if (_outFile) {
				if (!_append) {
					fdout = open(_outFile,O_CREAT| O_TRUNC | O_WRONLY);
				} else {
					fdout = open(_outFile,O_CREAT | O_APPEND | O_WRONLY);
				}
			} else {
				fdout = dup(tmpout);
			}
		} else {
			int fdpipe[2];
			pipe(fdpipe);
			fdout = fdpipe[1];
			fdin = fdpipe[0];
		}
		if (_errFile) {
			dup2(fdout,2);
		} else {
			dup2(fdout,1);
		}
		//dup2(fdout,1);
		close(fdout);
		if (!strcmp( _simpleCommands[i]->_arguments[0], "setenv" ) ) {
			//setenv(_simpleCommands[i]->_arguments[1],_simpleCommands[i]->_arguments[2],1);
			char * comb = (char *)malloc(strlen(_simpleCommands[i]->_arguments[1]) + strlen(_simpleCommands[i]->_arguments[2]));
			comb = strdup(_simpleCommands[i]->_arguments[1]);
			comb[strlen(_simpleCommands[i]->_arguments[1])] = '=';
			strcat(comb,_simpleCommands[i]->_arguments[2]);
			putenv(comb);
			//free(comb); //Freeing causes problems.
			clear();
			prompt();
			return;
		}
		if (!strcmp( _simpleCommands[i]->_arguments[0], "unsetenv" ) ) {
			unsetenv(_simpleCommands[i]->_arguments[1]);
			clear();
			prompt();
			return;
		}

		if (!strcmp( _simpleCommands[i]->_arguments[0], "cd" ) ) {
			if (_simpleCommands[i]->_arguments[1] == NULL) {
				char * value = getenv("HOME");
				//chdir("/homes/aprabhak");
				chdir(value);
				clear();
				prompt();
				return;
			}
			int j = chdir(_simpleCommands[i]->_arguments[1]);
			//printf("%d",i);
			if (j == -1) {
				//printf("-bash: cd: %s: No such file or directory",_simpleCommands[i]->_arguments[1]);
				perror("chdir");
			}
			clear();
			prompt();
			return;
		}
		ret = fork();
		if (_background == 1) {
			pid = ret;
			//if(!strcmp(_simpleCommands[i]->_arguments[1],"${!}")) {
			//	printf("%d\n",pid);
			//	exit(0);
			//}
			//pid = ret;
		
		}
		if (ret == 0) {
			if (!strcmp(_simpleCommands[i]->_arguments[0],"printenv")) {
				char **p = environ;
				while (*p != NULL) {
					printf("%s\n",*p);
					p++;
				}
				exit(0);
			}
			//close(fdpipe[0]);
			//close(fdpipe[1]);
			//close( tmpin );
			//close( tmpout );
			//close( tmperr );
			execvp(_simpleCommands[i]->_arguments[0],_simpleCommands[i]->_arguments);
			perror("execvp");
			_exit(1);
		} else if (ret < 0) {
			perror("fork");
			return;
		} else {
			//printf("%d\n",ret);
		}

	}
	//int error = errno;
	//printf("%d\n",errno);
		dup2(tmpin,0);
		dup2(tmpout,1);
		dup2(tmperr,2);
		close(tmpin);
		close(tmpout);
		close(tmperr);
		if (!_background) {
			waitpid(ret,NULL,0);  //waitpid(ret, NULL); in slides does not work.
		}

	// Clear to prepare for next command
	clear();

	// Print new prompt
	prompt();
}

// Shell implementation

void
Command::prompt()
{
	if ( isatty(0) ) {
  	printf("myshell>");
	}
	//printf("myshell>");

	fflush(stdout);
}

Command Command::_currentCommand;
SimpleCommand * Command::_currentSimpleCommand; /*pointer to command*/

int yyparse(void);

main()
{
    signal(SIGINT,disp);
    signal(SIGTSTP,disp2);
	Command::_currentCommand.prompt();
	struct sigaction signalAction;
	signalAction.sa_handler = killzombie;
	sigemptyset(&signalAction.sa_mask);
	signalAction.sa_flags = SA_RESTART;
	int error = sigaction(SIGCHLD, &signalAction, NULL );
	//int error2 = sigaction(SIGTSTP, &signalAction, NULL);
	if ( error ) {
		perror( "sigaction" );
		exit( -1 );
	}
	//signal(SIGTSTP,disp2);
	yyparse();
}
